# Plagiarism-Tester.codeclause
Plagiarism checker website using HTML,CSS,JAVASCRIPT
